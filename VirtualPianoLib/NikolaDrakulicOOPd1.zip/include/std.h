#ifndef _std_h
#define _std_h

#include <cstddef>
#include <iostream>
#include <string>

using std::cin;  // NOLINT
using std::cout; // NOLINT
using std::endl; // NOLINT
using std::ostream;
using std::string;

#endif